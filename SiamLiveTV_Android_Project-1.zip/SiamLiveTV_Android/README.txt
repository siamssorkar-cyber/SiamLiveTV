Siam Live TV Android Project

This is a WebView Android project containing the supplied Siam Live TV HTML.

Build:
1. Open the folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on Android.

The app requires INTERNET permission and loads the HTML from app assets.
Some third-party M3U8 streams may be unavailable or may block WebView/CORS independently of the app.
